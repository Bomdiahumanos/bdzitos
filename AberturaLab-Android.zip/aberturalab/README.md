# AberturaLab — treinador de repertório de xadrez

Protótipo de site local que busca partidas públicas do Chess.com, calcula estatísticas do repertório e pode usar Stockfish para encontrar decisões de abertura que merecem revisão.

## O que faz nesta versão

- Busca PGNs pela API pública do Chess.com, sem pedir senha.
- Permite importar um arquivo `.pgn` exportado do Chess.com.
- Separa estatísticas por abertura e por cor; mostra vitórias, empates, derrotas, taxa de vitória e pontuação.
- Procura padrões em posições de abertura repetidas, agrupando o seu lance com a resposta imediata do adversário.
- Com Stockfish instalado, analisa as decisões do usuário até um limite de lance configurável.
- Transforma imprecisões/erros encontrados em exercícios com tabuleiro, resposta revelável e CSV para guardar os pontos a estudar.

## Requisitos

- Python 3.10 ou mais recente recomendado.
- Conexão à internet para baixar as partidas do Chess.com.
- Stockfish é opcional para estatísticas; é necessário apenas para análise de engine.

## Instalação

1. Descompacte a pasta.
2. Abra o terminal dentro da pasta `aberturalab`.
3. Crie um ambiente virtual (recomendado):

   **Windows (PowerShell)**

   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   streamlit run app.py
   ```

   **Linux/macOS**

   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   streamlit run app.py
   ```

4. O navegador abrirá o site local. Se não abrir, copie o endereço local exibido no terminal (normalmente `http://localhost:8501`).
5. Na lateral, deixe `Machadodea6` no campo de usuário e clique em **Buscar minhas partidas**.

## Configurar Stockfish

1. Baixe uma versão apropriada para seu sistema no site oficial: <https://stockfishchess.org/download/>.
2. Extraia o arquivo baixado. No Windows, localize `stockfish.exe`; no Linux/macOS, localize o executável `stockfish`.
3. No AberturaLab, expanda **Configurar análise de engine** e informe o caminho do executável. Se Stockfish estiver no `PATH`, o nome `stockfish` basta.
4. Comece com 20 partidas, 0,20 segundo por posição e até o lance 12. Em computadores mais lentos, diminua a quantidade de partidas; para análises mais profundas, aumente o tempo por posição.
5. Clique em **Analisar aberturas com Stockfish**. A engine roda localmente no computador.

## Importar PGN

Selecione **Arquivo PGN** na lateral e escolha um arquivo `.pgn`. Para atribuir corretamente cor, vitórias e derrotas, o PGN deve manter os nomes dos jogadores nas tags `White` e `Black`; o usuário informado precisa aparecer em uma delas.

## Cuidados ao interpretar os resultados

- A API pública do Chess.com é somente leitura e pode ter atraso de atualização/cache. Não há login nem senha neste aplicativo.
- O resultado de uma abertura depende da amostra, cor, controle de tempo, força dos adversários e período. Uma abertura com 2 partidas não permite concluir que uma linha é ruim.
- O agrupamento de respostas é observacional: mostra resultados em posições repetidas, não demonstra por si só uma refutação teórica.
- Stockfish avalia posições, não explica automaticamente o plano humano. Use os exercícios e a linha sugerida como ponto de partida para investigar a ideia.
- A classificação em centipawns depende do tempo por posição e da versão da engine.

## Limitações conhecidas do protótipo

- A análise de engine está focada nas jogadas do usuário durante a abertura; não é um relatório completo de meio-jogo/finais.
- O nome da abertura depende das tags presentes no PGN. Sem tags, a partida aparece como `Abertura não identificada`.
- As respostas recorrentes são agrupadas por posição exata (tabuleiro, lado a jogar, roques e en passant), para evitar juntar linhas diferentes que apenas têm lances parecidos.
- O ranking de respostas não substitui o explorador de aberturas nem a análise com a engine em grande profundidade.

## Próximas melhorias possíveis

1. Reconhecimento/normalização de variantes ECO quando o PGN não contém as tags.
2. Comparar a taxa de sucesso das respostas reais com uma base externa de partidas de mestres.
3. Revisão espaçada dos exercícios e exportação de um pacote PGN com posições-chave.
4. Análise de tendências por faixa de rating, ritmo, fase do torneio e desempenho recente.
5. Suporte a outras engines UCI, se o executável estiver instalado localmente.

## Usar no celular Android (publicar como site)

O jeito mais simples é hospedar o AberturaLab e abrir o link pelo Chrome. Não é um APK: funciona como um site responsivo.

1. Extraia `AberturaLab.zip`.
2. Entre no GitHub pelo navegador e crie um repositório novo chamado `aberturalab`.
3. Envie para esse repositório os arquivos e pastas que estão dentro da pasta `aberturalab` (incluindo `app.py`, `requirements.txt` e `packages.txt`).
4. Entre em `https://share.streamlit.io/` e faça login com o GitHub.
5. Crie um app novo, escolha o repositório `aberturalab`, a branch principal e o arquivo `app.py`.
6. Aguarde a instalação e abra o endereço `.streamlit.app` que for criado. No Android, use o menu do Chrome → **Adicionar à tela inicial** para criar um atalho.

### Stockfish na hospedagem

O arquivo `packages.txt` pede ao ambiente Linux da hospedagem para instalar o Stockfish. Na tela de análise, tente primeiro o caminho `stockfish`. A disponibilidade de memória e o tempo de análise dependem do plano e dos recursos oferecidos pela hospedagem.

### Privacidade e limites

- O site usa partidas públicas da API do Chess.com e/ou arquivos PGN que você enviar.
- Não informe senha do Chess.com.
- Ao hospedar o projeto, o código e o processamento passam a rodar no serviço de hospedagem escolhido; leia as configurações de privacidade desse serviço antes de enviar PGNs privados.
- Esta é uma versão inicial: confira os resultados e as linhas sugeridas pela engine antes de mudar seu repertório.
